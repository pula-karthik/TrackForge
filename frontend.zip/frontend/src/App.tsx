import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { useAuthStore } from '@/store';
import { LoginPage } from '@/pages/LoginPage';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { TicketsPage } from '@/pages/TicketsPage';
import { TicketDetailPage } from '@/pages/TicketDetailPage';
import { NotificationsPage } from '@/pages/NotificationsPage';
import { ProfilePage } from '@/pages/ProfilePage';
import { AdminUsersPage } from '@/pages/AdminUsersPage';
import { ManagerDashboardPage } from '@/pages/ManagerDashboardPage';
import './index.css';

const PrivateRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAuthenticated } = useAuthStore();
  return isAuthenticated ? <>{children}</> : <Navigate to="/login" />;
};

const RoleRoute: React.FC<{ roles: string[]; children: React.ReactNode }> = ({ roles, children }) => {
  const user = useAuthStore((state) => state.user);
  return user && roles.includes(user.role) ? <>{children}</> : <Navigate to="/dashboard" replace />;
};

const DashboardHome: React.FC = () => {
  const user = useAuthStore((state) => state.user);
  if (user?.role === 'MANAGER') return <ManagerDashboardPage />;
  if (user?.role === 'ADMIN') return <AdminUsersPage />;
  return <TicketsPage />;
};

const TicketRoleRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <RoleRoute roles={['USER', 'AGENT', 'MANAGER']}>{children}</RoleRoute>
);

export const App: React.FC = () => {
  const initializeAuth = useAuthStore((state) => state.initializeAuth);

  React.useEffect(() => {
    initializeAuth();
  }, [initializeAuth]);

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route
          path="/dashboard"
          element={
            <PrivateRoute>
              <DashboardLayout>
                <DashboardHome />
              </DashboardLayout>
            </PrivateRoute>
          }
        />
        <Route
          path="/tickets"
          element={
            <PrivateRoute>
              <TicketRoleRoute>
                <DashboardLayout><TicketsPage /></DashboardLayout>
              </TicketRoleRoute>
            </PrivateRoute>
          }
        />
        <Route
          path="/tickets/:id"
          element={
            <PrivateRoute>
              <TicketRoleRoute>
                <DashboardLayout><TicketDetailPage /></DashboardLayout>
              </TicketRoleRoute>
            </PrivateRoute>
          }
        />
        <Route
          path="/notifications"
          element={
            <PrivateRoute>
              <TicketRoleRoute>
                <DashboardLayout><NotificationsPage /></DashboardLayout>
              </TicketRoleRoute>
            </PrivateRoute>
          }
        />
        <Route
          path="/profile"
          element={
            <PrivateRoute>
              <DashboardLayout>
                <ProfilePage />
              </DashboardLayout>
            </PrivateRoute>
          }
        />
        <Route
          path="/admin/users"
          element={
            <PrivateRoute>
              <RoleRoute roles={['ADMIN']}>
                <DashboardLayout>
                  <AdminUsersPage />
                </DashboardLayout>
              </RoleRoute>
            </PrivateRoute>
          }
        />
        <Route path="/" element={<Navigate to="/dashboard" />} />
      </Routes>
      <Toaster position="top-right" />
    </BrowserRouter>
  );
};

export default App;

