import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { apiClient, ManagerStatistics } from '@/services/api';
import toast from 'react-hot-toast';

export const ManagerDashboardPage: React.FC = () => {
  const [statistics, setStatistics] = useState<ManagerStatistics | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isDownloading, setIsDownloading] = useState(false);
  const [agents, setAgents] = useState<any[]>([]);

  const loadStatistics = async () => {
    try {
      setStatistics(await apiClient.getManagerStatistics());
      setAgents(await apiClient.getAllAgents());
    } catch {
      toast.error('Failed to load manager statistics');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadStatistics();
  }, []);

  const downloadReport = async () => {
    setIsDownloading(true);
    try {
      const blob = await apiClient.downloadManagerReport();
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `ticket-manager-report-${new Date().toISOString().slice(0, 10)}.xlsx`;
      link.click();
      URL.revokeObjectURL(url);
      toast.success('Manager report downloaded');
    } catch {
      toast.error('Failed to download manager report');
    } finally {
      setIsDownloading(false);
    }
  };

  if (isLoading) {
    return <div className="text-center py-12">Loading manager statistics...</div>;
  }

  if (!statistics) {
    return <div className="card text-center py-12">Statistics are unavailable.</div>;
  }

  const summaryCards = [
    { label: 'Total Tickets', value: statistics.totalTickets, color: 'text-blue-600' },
    { label: 'Open Tickets', value: statistics.openTickets, color: 'text-orange-600' },
    { label: 'Waiting for User', value: statistics.waitingTickets, color: 'text-purple-600' },
    { label: 'In Progress', value: statistics.inProgressTickets, color: 'text-indigo-600' },
    { label: 'Resolved Tickets', value: statistics.resolvedTickets, color: 'text-green-600' },
    { label: 'Closed Tickets', value: statistics.closedTickets, color: 'text-gray-600' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Manager Dashboard</h1>
          <p className="text-gray-600 mt-1">Ticket status and agent workload overview.</p>
        </div>
        <div className="flex gap-3">
          <Link to="/tickets" className="btn-secondary">View All Tickets</Link>
          <button onClick={downloadReport} disabled={isDownloading} className="btn-primary disabled:opacity-50">
            {isDownloading ? 'Preparing...' : '⬇ Download Report'}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {summaryCards.map((card) => (
          <div key={card.label} className="card">
            <p className="text-sm text-gray-500">{card.label}</p>
            <p className={`text-3xl font-bold mt-2 ${card.color}`}>{card.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <section className="card">
          <h2 className="text-xl font-bold text-gray-800 mb-4">Tickets by Status</h2>
          <div className="space-y-3">
            {Object.entries(statistics.statusCounts).map(([status, count]) => (
              <div key={status} className="flex items-center justify-between border-b border-gray-100 pb-2">
                <span className="text-gray-600">{status.replace(/_/g, ' ')}</span>
                <span className="font-semibold text-gray-800">{count}</span>
              </div>
            ))}
          </div>
        </section>

        <section className="card overflow-x-auto">
          <h2 className="text-xl font-bold text-gray-800 mb-4">Agent Workload</h2>
          <table className="min-w-full text-left">
            <thead>
              <tr className="border-b border-gray-200 text-sm text-gray-500">
                <th className="py-2 pr-4">Agent</th>
                <th className="py-2 pr-4">Department</th>
                <th className="py-2 pr-4">Availability</th>
                <th className="py-2 pr-4">Open</th>
                <th className="py-2 pr-4">Waiting</th>
                <th className="py-2 pr-4">In Progress</th>
                <th className="py-2 pr-4">Resolved</th>
                <th className="py-2 pr-4">Closed</th>
                <th className="py-2">Total</th>
              </tr>
            </thead>
            <tbody>
              {statistics.agentWorkloads.map((agent) => (
                <tr key={agent.agentId} className="border-b border-gray-100">
                  <td className="py-3 pr-4">
                    <p className="font-medium">{agent.name}</p>
                    <p className="text-xs text-gray-500">@{agent.username}</p>
                  </td>
                  <td className="py-3 pr-4">{agents.find((item) => item.id === agent.agentId)?.department || 'SUPPORT'}</td>
                  <td className="py-3 pr-4">
                    <span className={`inline-flex rounded-full px-2 py-1 text-xs font-semibold ${
                      agents.find((item) => item.id === agent.agentId)?.status === 'ACTIVE'
                        ? 'bg-green-100 text-green-700'
                        : 'bg-gray-100 text-gray-600'
                    }`}>
                      {agents.find((item) => item.id === agent.agentId)?.status === 'ACTIVE' ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="py-3 pr-4 font-semibold text-orange-600">{agent.openTickets}</td>
                  <td className="py-3 pr-4">{agent.waitingTickets}</td>
                  <td className="py-3 pr-4">{agent.inProgressTickets}</td>
                  <td className="py-3 pr-4">{agent.resolvedTickets}</td>
                  <td className="py-3 pr-4">{agent.closedTickets}</td>
                  <td className="py-3">{agent.totalTickets}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      </div>
    </div>
  );
};

