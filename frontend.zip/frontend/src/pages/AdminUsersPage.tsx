import React, { useEffect, useState } from 'react';
import { apiClient } from '@/services/api';
import toast from 'react-hot-toast';

type ManagedUser = {
  id: number;
  username: string;
  email: string;
  firstName: string;
  lastName: string;
  role: string;
  department?: string;
  status: string;
};

const emptyForm = {
  username: '',
  password: '',
  email: '',
  firstName: '',
  lastName: '',
  role: 'USER',
  department: 'SUPPORT',
};

export const AdminUsersPage: React.FC = () => {
  const [users, setUsers] = useState<ManagedUser[]>([]);
  const [form, setForm] = useState(emptyForm);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  const loadUsers = async () => {
    setIsLoading(true);
    try {
      const response = await apiClient.getUsers();
      setUsers(response.content || []);
    } catch {
      toast.error('Failed to load users');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadUsers();
  }, []);

  const handleCreate = async (event: React.FormEvent) => {
    event.preventDefault();
    setIsSaving(true);
    try {
      await apiClient.createUser(form);
      toast.success('User created successfully');
      setForm(emptyForm);
      await loadUsers();
    } catch (error: any) {
      toast.error(error.response?.data || 'Failed to create user');
    } finally {
      setIsSaving(false);
    }
  };

  const updateUser = async (user: ManagedUser, field: 'status' | 'role' | 'department', value: string) => {
    try {
      await apiClient.updateUser(user.id, {
        firstName: user.firstName,
        lastName: user.lastName,
        status: field === 'status' ? value : user.status,
        role: field === 'role' ? value : user.role,
        department: field === 'department' ? value : user.department,
      });
      setUsers((current) => current.map((item) => (
        item.id === user.id ? { ...item, [field]: value } : item
      )));
      toast.success('User updated');
    } catch {
      toast.error('Failed to update user');
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-800">User Management</h1>
        <p className="text-gray-600 mt-1">Create accounts and manage roles or account status.</p>
      </div>

      <form onSubmit={handleCreate} className="card grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        <h2 className="md:col-span-2 xl:col-span-3 text-xl font-bold text-gray-800">Add User</h2>
        {(['username', 'password', 'email', 'firstName', 'lastName'] as const).map((field) => (
          <input
            key={field}
            type={field === 'password' ? 'password' : field === 'email' ? 'email' : 'text'}
            required
            placeholder={field === 'firstName' ? 'First name' : field === 'lastName' ? 'Last name' : field[0].toUpperCase() + field.slice(1)}
            value={form[field]}
            onChange={(event) => setForm({ ...form, [field]: event.target.value })}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
          />
        ))}
        <select
          value={form.role}
          onChange={(event) => setForm({ ...form, role: event.target.value })}
          className="px-3 py-2 border border-gray-300 rounded-lg"
        >
          <option value="USER">User</option>
          <option value="AGENT">Agent</option>
          <option value="MANAGER">Manager</option>
        </select>
        <select
          value={form.department}
          onChange={(event) => setForm({ ...form, department: event.target.value })}
          className="px-3 py-2 border border-gray-300 rounded-lg"
        >
          <option value="DEVELOPER">Developer</option>
          <option value="ADMIN">Admin Team</option>
          <option value="SUPPORT">Support</option>
          <option value="SECURITY">Security</option>
          <option value="OPERATIONS">Operations</option>
        </select>
        <button type="submit" disabled={isSaving} className="btn-primary disabled:opacity-50">
          {isSaving ? 'Creating...' : 'Create User'}
        </button>
      </form>

      <div className="card overflow-x-auto p-0">
        {isLoading ? (
          <p className="p-6 text-gray-500">Loading users...</p>
        ) : (
          <table className="min-w-full text-left">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-4 py-3 text-sm font-semibold">User</th>
                <th className="px-4 py-3 text-sm font-semibold">Email</th>
                <th className="px-4 py-3 text-sm font-semibold">Role</th>
                <th className="px-4 py-3 text-sm font-semibold">Department</th>
                <th className="px-4 py-3 text-sm font-semibold">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {users.map((user) => (
                <tr key={user.id}>
                  <td className="px-4 py-3">
                    <p className="font-medium">{user.firstName} {user.lastName}</p>
                    <p className="text-sm text-gray-500">@{user.username}</p>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-gray-600">{user.email}</span>
                  </td>
                  <td className="px-4 py-3">
                    <select value={user.role} onChange={(event) => updateUser(user, 'role', event.target.value)} className="border rounded px-2 py-1">
                      <option value="USER">User</option>
                      <option value="AGENT">Agent</option>
                      <option value="MANAGER">Manager</option>
                      <option value="ADMIN">Admin</option>
                    </select>
                  </td>
                  <td className="px-4 py-3">
                    <select value={user.department || 'SUPPORT'} onChange={(event) => updateUser(user, 'department', event.target.value)} className="border rounded px-2 py-1">
                      <option value="DEVELOPER">Developer</option>
                      <option value="ADMIN">Admin Team</option>
                      <option value="SUPPORT">Support</option>
                      <option value="SECURITY">Security</option>
                      <option value="OPERATIONS">Operations</option>
                    </select>
                  </td>
                  <td className="px-4 py-3">
                    <select value={user.status} onChange={(event) => updateUser(user, 'status', event.target.value)} className="border rounded px-2 py-1">
                      <option value="ACTIVE">Active</option>
                      <option value="INACTIVE">Inactive</option>
                      <option value="LOCKED">Locked</option>
                      <option value="SUSPENDED">Suspended</option>
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

