import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { apiClient, Notification } from '@/services/api';
import toast from 'react-hot-toast';

export const NotificationsPage: React.FC = () => {
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchNotifications();
  }, []);

  const fetchNotifications = async () => {
    setIsLoading(true);
    try {
      const data = await apiClient.getNotifications();
      setNotifications(data.content || []);
    } catch (error) {
      toast.error('Failed to load notifications');
    } finally {
      setIsLoading(false);
    }
  };

  const handleNotificationClick = async (notification: Notification) => {
    setNotifications((current) => current.filter((item) => item.id !== notification.id));
    try {
      if (!notification.isRead) {
        await apiClient.markAsRead(notification.id);
      }
    } catch (error) {
      toast.error('Failed to mark as read');
    } finally {
      if (notification.ticketId) {
        navigate(`/tickets/${notification.ticketId}`);
      }
    }
  };

  const formatTime = (createdAt: string) => {
    const date = new Date(createdAt);
    const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
    if (seconds < 60) return 'Just now';
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
    return date.toLocaleString();
  };

  const unreadCount = notifications.filter((notification) => !notification.isRead).length;

  return (
    <div className="space-y-6">
      <div className="rounded-2xl bg-gradient-to-r from-blue-700 to-indigo-600 p-6 text-white shadow-lg">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="text-sm font-medium uppercase tracking-wider text-blue-100">Activity center</p>
            <h1 className="mt-1 text-3xl font-bold">Notifications</h1>
            <p className="mt-2 text-blue-100">Stay updated on your tickets and team activity.</p>
          </div>
          <div className="rounded-xl bg-white/15 px-5 py-3 text-center backdrop-blur-sm">
            <p className="text-2xl font-bold">{unreadCount}</p>
            <p className="text-xs text-blue-100">Unread</p>
          </div>
        </div>
      </div>

      {isLoading ? (
        <div className="text-center py-12">Loading notifications...</div>
      ) : notifications.length === 0 ? (
        <div className="card border-dashed py-16 text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-blue-50 text-3xl">✓</div>
          <p className="text-lg font-semibold text-gray-800">You’re all caught up</p>
          <p className="mt-1 text-gray-500">New ticket activity will appear here.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {notifications.map((notification) => (
            <button
              key={notification.id}
              type="button"
              className={`card cursor-pointer transition-all ${
                !notification.isRead
                  ? 'border-l-4 border-blue-600 bg-blue-50 shadow-md hover:bg-blue-100'
                  : 'hover:-translate-y-0.5 hover:shadow-md'
              }`}
              onClick={() => handleNotificationClick(notification)}
            >
              <div className="flex w-full items-start gap-4 text-left">
                <div className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-xl ${notification.isRead ? 'bg-gray-100' : 'bg-blue-100'}`}>
                  {notification.isRead ? '•' : '🔔'}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <h4 className="font-semibold text-gray-800">{notification.title}</h4>
                    <span className={`text-xs font-medium ${notification.isRead ? 'text-gray-400' : 'text-blue-700'}`}>
                      {formatTime(notification.createdAt)}
                    </span>
                  </div>
                  <p className="mt-1 text-sm leading-6 text-gray-600">{notification.message}</p>
                  <p className="mt-2 text-xs text-gray-400">{new Date(notification.createdAt).toLocaleString()}</p>
                </div>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
