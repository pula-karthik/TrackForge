import React, { useState, useEffect } from 'react';
import { useAuthStore } from '@/store';
import { apiClient } from '@/services/api';
import toast from 'react-hot-toast';

export const ProfilePage: React.FC = () => {
  const { user, setUser } = useAuthStore();
  const [isLoading, setIsLoading] = useState(true);
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      await apiClient.getProfile();
    } catch (error) {
      toast.error('Failed to load profile');
    } finally {
      setIsLoading(false);
    }
  };

  const updateAvailability = async (status: string) => {
    if (!user || user.role !== 'AGENT' || !['ACTIVE', 'INACTIVE'].includes(status)) return;
    setIsUpdatingStatus(true);
    try {
      const updated = await apiClient.updateUser(user.id, {
        firstName: user.firstName,
        lastName: user.lastName,
        status,
      });
      setUser({ ...user, status: updated.status || status });
      toast.success(status === 'ACTIVE' ? 'You are now available' : 'You are marked as on leave');
    } catch {
      toast.error('Failed to update availability');
    } finally {
      setIsUpdatingStatus(false);
    }
  };

  if (isLoading) {
    return <div className="text-center py-12">Loading profile...</div>;
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-800">My Profile</h1>

      <div className="card max-w-2xl">
        <div className="flex items-center gap-6 mb-6">
          <div className="w-24 h-24 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center text-white text-4xl">
            {user?.firstName.charAt(0)}{user?.lastName.charAt(0)}
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-800">
              {user?.firstName} {user?.lastName}
            </h2>
            <p className="text-gray-600">{user?.email}</p>
            <span className="inline-block mt-2 px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
              {user?.role}
            </span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-6 pt-6 border-t border-gray-200">
          <div>
            <p className="text-sm text-gray-600">Username</p>
            <p className="font-medium text-gray-800">{user?.username}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Status</p>
            {user?.role === 'AGENT' ? (
              <select
                value={user.status === 'INACTIVE' ? 'INACTIVE' : 'ACTIVE'}
                disabled={isUpdatingStatus}
                onChange={(event) => updateAvailability(event.target.value)}
                className="mt-1 border rounded px-2 py-1 font-medium text-gray-800"
              >
                <option value="ACTIVE">Active / Available</option>
                <option value="INACTIVE">Inactive / On Leave</option>
              </select>
            ) : (
              <p className="font-medium text-gray-800">{user?.status}</p>
            )}
          </div>
          <div>
            <p className="text-sm text-gray-600">First Name</p>
            <p className="font-medium text-gray-800">{user?.firstName}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Last Name</p>
            <p className="font-medium text-gray-800">{user?.lastName}</p>
          </div>
        </div>
      </div>

      <div className="card max-w-2xl">
        <h3 className="text-xl font-bold text-gray-800 mb-4">Role Permissions</h3>
        <div className="space-y-3">
          {user?.role === 'USER' && (
            <>
              <p className="flex items-center gap-2">✅ Create and manage tickets</p>
              <p className="flex items-center gap-2">✅ View ticket status and history</p>
              <p className="flex items-center gap-2">✅ Add comments to tickets</p>
            </>
          )}
          {user?.role === 'AGENT' && (
            <>
              <p className="flex items-center gap-2">✅ View assigned tickets</p>
              <p className="flex items-center gap-2">✅ Update ticket status</p>
              <p className="flex items-center gap-2">✅ Add comments and notes</p>
              <p className="flex items-center gap-2">✅ Resolve tickets</p>
            </>
          )}
          {user?.role === 'MANAGER' && (
            <>
              <p className="flex items-center gap-2">✅ View all team tickets</p>
              <p className="flex items-center gap-2">✅ View agent workload</p>
              <p className="flex items-center gap-2">✅ Reassign tickets</p>
              <p className="flex items-center gap-2">✅ View team statistics</p>
            </>
          )}
          {user?.role === 'ADMIN' && (
            <>
              <p className="flex items-center gap-2">✅ Manage users and agents</p>
              <p className="flex items-center gap-2">✅ Update people status and roles</p>
              <p className="flex items-center gap-2">✅ View and update your own profile</p>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

