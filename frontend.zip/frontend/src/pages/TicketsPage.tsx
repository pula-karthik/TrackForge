import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { apiClient, Ticket } from '@/services/api';
import { useAuthStore } from '@/store';
import toast from 'react-hot-toast';

export const TicketsPage: React.FC = () => {
  const { user } = useAuthStore();
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDownloading, setIsDownloading] = useState(false);
  const [priorityFilter, setPriorityFilter] = useState('ALL');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [formData, setFormData] = useState({
    summary: '',
    description: '',
    category: 'TECHNICAL',
    priority: 'LOW',
  });

  useEffect(() => {
    fetchTickets();
  }, []);

  const fetchTickets = async () => {
    setIsLoading(true);
    try {
      const data = user?.role === 'MANAGER'
        ? await apiClient.getAllTickets()
        : (await apiClient.getTickets()).content;
      setTickets(data || []);
    } catch (error) {
      toast.error('Failed to load tickets');
    } finally {
      setIsLoading(false);
    }
  };

  const downloadTickets = () => {
    if (tickets.length === 0) {
      toast.error('There are no tickets to download');
      return;
    }

    setIsDownloading(true);
    try {
      const headers = ['Ticket Number', 'Summary', 'Description', 'Category', 'Priority', 'Status', 'Reporter', 'Assignee', 'Created At'];
      const escapeCsv = (value: unknown) => `"${String(value ?? '').replace(/"/g, '""')}"`;
      const rows = tickets.map((ticket) => [
        ticket.ticketNumber,
        ticket.summary,
        ticket.description,
        ticket.category,
        ticket.priority,
        ticket.status,
        ticket.reporterName,
        ticket.assigneeName || 'Unassigned',
        new Date(ticket.createdAt).toLocaleString(),
      ]);
      const csv = [headers, ...rows].map((row) => row.map(escapeCsv).join(',')).join('\r\n');
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `tickets-${new Date().toISOString().slice(0, 10)}.csv`;
      link.click();
      URL.revokeObjectURL(url);
      toast.success(`${tickets.length} tickets downloaded`);
    } finally {
      setIsDownloading(false);
    }
  };

  const handleCreateTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await apiClient.createTicket(formData);
      toast.success('Ticket created successfully!');
      setShowCreateModal(false);
      setFormData({ summary: '', description: '', category: 'TECHNICAL', priority: 'LOW' });
      fetchTickets();
    } catch (error) {
      toast.error('Failed to create ticket');
    }
  };

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      OPEN: 'badge-info',
      ASSIGNED: 'badge-warning',
      IN_PROGRESS: 'badge-warning',
      RESOLVED: 'badge-success',
      CLOSED: 'badge-success',
    };
    return colors[status] || 'badge-info';
  };

  const getPriorityColor = (priority: string) => {
    const colors: Record<string, string> = {
      LOW: 'text-green-600',
      MEDIUM: 'text-yellow-600',
      HIGH: 'text-orange-600',
      URGENT: 'text-red-600',
    };
    return colors[priority] || 'text-gray-600';
  };

  const visibleTickets = priorityFilter === 'ALL'
    ? tickets
    : tickets.filter((ticket) => ticket.priority === priorityFilter);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-3xl font-bold text-gray-800">Tickets</h1>
        <div className="flex flex-wrap gap-3">
          {user?.role === 'MANAGER' && (
            <button onClick={downloadTickets} disabled={isDownloading} className="btn-secondary disabled:opacity-50">
              {isDownloading ? 'Preparing...' : '⬇ Download Tickets'}
            </button>
          )}
          {user?.role === 'USER' && (
            <button onClick={() => setShowCreateModal(true)} className="btn-primary">
              + New Ticket
            </button>
          )}
        </div>
      </div>

      <div className="flex flex-wrap gap-2" aria-label="Filter tickets by priority">
        {['ALL', 'URGENT', 'HIGH', 'MEDIUM', 'LOW'].map((priority) => (
          <button
            key={priority}
            type="button"
            onClick={() => setPriorityFilter(priority)}
            className={`px-3 py-2 rounded-lg text-sm font-medium transition ${
              priorityFilter === priority
                ? 'bg-blue-600 text-white'
                : 'bg-white text-gray-700 border border-gray-200 hover:bg-blue-50'
            }`}
          >
            {priority === 'ALL' ? 'All Priorities' : priority}
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className="text-center py-12">
          <p className="text-gray-500">Loading tickets...</p>
        </div>
      ) : visibleTickets.length === 0 ? (
        <div className="card text-center py-12">
          <p className="text-gray-500 text-lg">No {priorityFilter === 'ALL' ? '' : priorityFilter.toLowerCase()} tickets found</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {visibleTickets.map((ticket) => (
            <Link
              key={ticket.id}
              to={`/tickets/${ticket.id}`}
              className="card block min-w-0 hover:shadow-lg cursor-pointer"
            >
              <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-3 mb-2">
                    <h3 className="min-w-0 break-words text-lg font-semibold text-gray-800">{ticket.ticketNumber}</h3>
                    <span className={`badge ${getStatusColor(ticket.status)}`}>{ticket.status}</span>
                  </div>
                  <p className="break-words text-gray-700 font-medium mb-2">{ticket.summary}</p>
                  <p className="break-words text-gray-600 text-sm mb-3 line-clamp-3">{ticket.description}</p>
                  <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-gray-500">
                    <span className="break-words">Category: {ticket.category}</span>
                    {ticket.department && <span className="break-words">Team: {ticket.department}</span>}
                    <span className={`font-medium ${getPriorityColor(ticket.priority)}`}>
                      Priority: {ticket.priority}
                    </span>
                    <span>Created: {new Date(ticket.createdAt).toLocaleDateString()}</span>
                    {ticket.slaDueAt && (
                      <span className={new Date(ticket.slaDueAt) < new Date() ? 'font-semibold text-red-600' : ''}>
                        SLA: {new Date(ticket.slaDueAt).toLocaleString()}
                      </span>
                    )}
                  </div>
              </div>
            </Link>
          ))}
        </div>
      )}

      {showCreateModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-xl font-bold">Create New Ticket</h2>
            </div>
            <form onSubmit={handleCreateTicket} className="p-6 space-y-4">
              <input
                type="text"
                placeholder="Summary"
                value={formData.summary}
                onChange={(e) => setFormData({ ...formData, summary: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              />
              <textarea
                placeholder="Description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                rows={4}
                required
              />
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg"
              >
                <option value="TECHNICAL">Technical</option>
                <option value="BILLING">Billing</option>
                <option value="GENERAL_INQUIRY">General</option>
                <option value="FEATURE_REQUEST">Feature Request</option>
                <option value="BUG_REPORT">Bug Report</option>
                <option value="SECURITY">Security</option>
                <option value="OPERATIONS">Operations</option>
                <option value="OTHER">Other</option>
              </select>
              <select
                value={formData.priority}
                onChange={(e) => setFormData({ ...formData, priority: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg"
              >
                <option value="LOW">Low</option>
                <option value="MEDIUM">Medium</option>
                <option value="HIGH">High</option>
                <option value="URGENT">Urgent</option>
              </select>
              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="btn-secondary flex-1"
                >
                  Cancel
                </button>
                <button type="submit" className="btn-primary flex-1">
                  Create Ticket
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
