import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { apiClient, Ticket } from '@/services/api';
import { useAuthStore } from '@/store';
import toast from 'react-hot-toast';

export const TicketDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const user = useAuthStore((state) => state.user);
  const [ticket, setTicket] = useState<Ticket | null>(null);
  const [comments, setComments] = useState<any[]>([]);
  const [agents, setAgents] = useState<any[]>([]);
  const [newComment, setNewComment] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchTicketDetails();
  }, [id]);

  useEffect(() => {
    if (user?.role === 'MANAGER') {
      apiClient.getAgents().then(setAgents).catch(() => toast.error('Failed to load agents'));
    }
  }, [user]);

  const fetchTicketDetails = async () => {
    if (!id) return;
    setIsLoading(true);
    try {
      const ticketData = await apiClient.getTicket(parseInt(id));
      setTicket(ticketData);
      const commentsData = await apiClient.getComments(parseInt(id));
      setComments(commentsData.content || []);
    } catch (error) {
      toast.error('Failed to load ticket details');
      navigate('/dashboard');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!id || !newComment.trim()) return;

    try {
      await apiClient.addComment(parseInt(id), newComment);
      toast.success('Comment added!');
      setNewComment('');
      fetchTicketDetails();
    } catch (error) {
      toast.error('Failed to add comment');
    }
  };

  const handleUpdateStatus = async (newStatus: string) => {
    if (!id) return;
    try {
      await apiClient.updateTicketStatus(parseInt(id), newStatus);
      toast.success('Status updated!');
      fetchTicketDetails();
    } catch (error) {
      toast.error('Failed to update status');
    }
  };

  const handleReassign = async (agentId: string) => {
    if (!id || !agentId) return;
    const agent = agents.find((item) => String(item.id) === agentId);
    if (!agent) return;
    try {
      const updatedTicket = await apiClient.reassignTicket(parseInt(id), agent.username);
      setTicket(updatedTicket);
      toast.success(`Ticket assigned to ${agent.username}`);
    } catch {
      toast.error('Failed to assign ticket');
    }
  };

  if (isLoading) {
    return <div className="text-center py-12">Loading ticket...</div>;
  }

  if (!ticket) {
    return <div className="text-center py-12">Ticket not found</div>;
  }

  return (
    <div className="space-y-6">
      <button
        onClick={() => navigate('/dashboard')}
        className="text-blue-600 hover:text-blue-800 flex items-center gap-2"
      >
        ← Back to Tickets
      </button>

      <div className="card">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-800">{ticket.ticketNumber}</h1>
            <p className="text-gray-600">{ticket.summary}</p>
          </div>
          {user && ['AGENT', 'MANAGER'].includes(user.role) ? (
            <select
              value={ticket.status}
              onChange={(e) => handleUpdateStatus(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            >
              <option value="OPEN">Open</option>
              <option value="ASSIGNED">Assigned</option>
              <option value="IN_PROGRESS">In Progress</option>
              <option value="WAITING_FOR_USER">Waiting for User</option>
              <option value="RESOLVED">Resolved</option>
              <option value="CLOSED">Closed</option>
            </select>
          ) : (
            <span className="badge badge-info">{ticket.status}</span>
          )}
        </div>

        <div className="grid grid-cols-2 gap-4 mb-6 pb-6 border-b border-gray-200">
          <div>
            <p className="text-sm text-gray-600">Category</p>
            <p className="font-medium">{ticket.category}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Priority</p>
            <p className={`font-medium ${ticket.priority === 'URGENT' ? 'text-red-600' : ticket.priority === 'MEDIUM' ? 'text-yellow-600' : ''}`}>
              {ticket.priority}
            </p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Handling Team</p>
            <p className="font-medium">{ticket.department || 'SUPPORT'}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600">SLA Due</p>
            <p className={`font-medium ${ticket.slaDueAt && new Date(ticket.slaDueAt) < new Date() ? 'text-red-600' : 'text-gray-800'}`}>
              {ticket.slaDueAt ? new Date(ticket.slaDueAt).toLocaleString() : 'Not calculated'}
            </p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Reporter</p>
            <p className="font-medium">{ticket.reporterName}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Assigned To</p>
            {user?.role === 'MANAGER' ? (
              <select
                value={ticket.assigneeId ? String(ticket.assigneeId) : ''}
                onChange={(event) => handleReassign(event.target.value)}
                className="mt-1 px-3 py-2 border border-gray-300 rounded-lg"
              >
                <option value="">{ticket.assigneeName || 'Unassigned'}</option>
                {agents.filter((agent) => !ticket.department || (agent.department || 'SUPPORT') === ticket.department).map((agent) => (
                  <option key={agent.id} value={agent.id}>{agent.username} — {agent.firstName} {agent.lastName}</option>
                ))}
              </select>
            ) : (
              <p className="font-medium">{ticket.assigneeName || 'Unassigned'}</p>
            )}
          </div>
        </div>

        <div>
          <h3 className="font-semibold text-gray-800 mb-2">Description</h3>
          <p className="text-gray-700 leading-relaxed">{ticket.description}</p>
        </div>
      </div>

      <div className="card">
        <h3 className="text-xl font-bold text-gray-800 mb-4">Comments</h3>
        <div className="space-y-4 mb-6">
          {comments.map((comment, index) => (
            <div key={index} className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <p className="font-medium text-gray-800">{comment.authorName}</p>
                <span className="text-xs text-gray-500">
                  {new Date(comment.createdAt).toLocaleString()}
                </span>
              </div>
              <p className="text-gray-700">{comment.content}</p>
            </div>
          ))}
        </div>

        <form onSubmit={handleAddComment} className="space-y-3">
          <textarea
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            placeholder="Add a comment..."
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            rows={4}
          />
          <button type="submit" className="btn-primary">
            Post Comment
          </button>
        </form>
      </div>
    </div>
  );
};

