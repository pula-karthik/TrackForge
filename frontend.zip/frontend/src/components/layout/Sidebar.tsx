import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useUIStore } from '@/store';
import clsx from 'clsx';

interface SidebarProps {
  user: any;
}

export const Sidebar: React.FC<SidebarProps> = ({ user }) => {
  const location = useLocation();
  const { sidebarOpen } = useUIStore();

  const menuItems = user?.role === 'ADMIN'
    ? [
        { label: 'Manage Users', href: '/admin/users', icon: '🛠️' },
        { label: 'Profile', href: '/profile', icon: '👤' },
      ]
    : [
        { label: 'Dashboard', href: '/dashboard', icon: '📊' },
        { label: 'Tickets', href: '/tickets', icon: '🎫' },
        ...(user?.role === 'MANAGER' ? [{ label: 'Reports', href: '/dashboard', icon: '📈' }] : []),
        { label: 'Notifications', href: '/notifications', icon: '🔔' },
        { label: 'Profile', href: '/profile', icon: '👤' },
      ];

  return (
    <div
      className={clsx(
        'relative h-full shrink-0 bg-gradient-to-b from-blue-600 to-blue-800 text-white transition-all duration-300 shadow-lg',
        sidebarOpen ? 'w-64' : 'w-20'
      )}
    >
      <div className="p-4 flex items-center gap-3">
        <span className="text-3xl">🎫</span>
        {sidebarOpen && <span className="text-xl font-bold">TrackForge</span>}
      </div>

      <nav className="mt-8 space-y-2">
        {menuItems.map((item) => (
          <Link
            key={item.href}
            to={item.href}
            className={clsx(
              'px-4 py-3 flex items-center gap-3 transition-all',
              location.pathname === item.href
                ? 'bg-blue-500 border-l-4 border-white'
                : 'hover:bg-blue-700'
            )}
          >
            <span className="text-xl">{item.icon}</span>
            {sidebarOpen && <span>{item.label}</span>}
          </Link>
        ))}
      </nav>

      {sidebarOpen && user && (
        <div className="absolute bottom-0 w-full p-4 bg-blue-700 text-sm">
          <p className="font-medium">{user.firstName} {user.lastName}</p>
          <p className="text-blue-200">{user.role}</p>
        </div>
      )}
    </div>
  );
};

