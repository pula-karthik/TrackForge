import React from 'react';
import { Link } from 'react-router-dom';
import { useUIStore } from '@/store';

interface NavbarProps {
  user: any;
  unreadCount: number;
  onLogout: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ user, unreadCount, onLogout }) => {
  const { toggleSidebar } = useUIStore();

  return (
    <div className="bg-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={toggleSidebar}
              className="p-2 hover:bg-gray-100 rounded-lg transition"
              title="Toggle sidebar"
            >
              ☰
            </button>
            <h1 className="text-2xl font-bold text-gray-800">TrackForge</h1>
          </div>

          <div className="flex items-center gap-6">
            {user?.role !== 'ADMIN' && (
              <Link
                to="/notifications"
                className="relative p-2 hover:bg-gray-100 rounded-lg transition"
              >
                <span className="text-2xl">🔔</span>
                {unreadCount > 0 && (
                  <span className="absolute top-1 right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {unreadCount > 9 ? '9+' : unreadCount}
                  </span>
                )}
              </Link>
            )}

            <div className="flex items-center gap-3 pl-6 border-l border-gray-200">
              <div className="text-right">
                <p className="font-medium text-gray-800">{user?.firstName}</p>
                <p className="text-sm text-gray-500">{user?.role}</p>
              </div>
              <button
                onClick={onLogout}
                className="btn-secondary py-1 px-3 text-sm"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

