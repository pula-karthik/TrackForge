import axios, { AxiosInstance } from 'axios';

const API_BASE_URL = '/api';

export interface LoginRequest {
  username: string;
  password: string;
}

export interface RegisterRequest {
  username: string;
  password: string;
  email: string;
  firstName: string;
  lastName: string;
  role?: string;
  department?: string;
}

export interface LoginResponse {
  accessToken: string;
  tokenType: string;
  expiresIn: number;
  user: {
    id: number;
    username: string;
    email: string;
    firstName: string;
    lastName: string;
    role: string;
    department?: string;
    status: string;
  };
}

export interface Ticket {
  id: number;
  ticketNumber: string;
  summary: string;
  description: string;
  category: string;
  priority: string;
  status: string;
  department?: string;
  reporterId: number;
  reporterName: string;
  assigneeId?: number;
  assigneeName?: string;
  createdAt: string;
  updatedAt: string;
  slaDueAt?: string;
}

export interface CreateTicketRequest {
  summary: string;
  description: string;
  category: string;
  priority: string;
  department?: string;
}

export interface Notification {
  id: number;
  recipientId: number;
  title: string;
  message: string;
  ticketId?: number;
  isRead: boolean;
  createdAt: string;
}

export interface TicketPage {
  content: Ticket[];
  totalElements: number;
  totalPages: number;
  number: number;
  size: number;
}

export interface ManagerStatistics {
  totalTickets: number;
  openTickets: number;
  pendingTickets: number;
  waitingTickets: number;
  inProgressTickets: number;
  resolvedTickets: number;
  closedTickets: number;
  statusCounts: Record<string, number>;
  agentWorkloads: Array<{
    agentId: number;
    username: string;
    name: string;
    totalTickets: number;
    openTickets: number;
    pendingTickets: number;
    waitingTickets: number;
    inProgressTickets: number;
    resolvedTickets: number;
    closedTickets: number;
  }>;
}

class ApiClient {
  private client: AxiosInstance;
  private token: string | null = null;

  constructor() {
    this.client = axios.create({
      baseURL: API_BASE_URL,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    this.client.interceptors.request.use((config) => {
      const token = localStorage.getItem('token');
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
      return config;
    });

    this.client.interceptors.response.use(
      (response) => response,
      (error) => {
        if (error.response?.status === 401 && error.config?.url !== '/auth/login') {
          localStorage.removeItem('token');
          localStorage.removeItem('user');
          window.location.href = '/login';
        }
        return Promise.reject(error);
      }
    );
  }

  // Auth
  async login(credentials: LoginRequest): Promise<LoginResponse> {
    const response = await this.client.post<LoginResponse>('/auth/login', credentials);
    this.token = response.data.accessToken;
    localStorage.setItem('token', this.token);
    localStorage.setItem('user', JSON.stringify(response.data.user));
    return response.data;
  }

  async register(data: any): Promise<any> {
    const response = await this.client.post('/auth/register', data);
    return response.data;
  }

  // Tickets
  async getTickets(page = 0, size = 20): Promise<TicketPage> {
    const response = await this.client.get<TicketPage>(`/tickets?page=${page}&size=${size}`);
    return response.data;
  }

  async getAllTickets(): Promise<Ticket[]> {
    const pageSize = 100;
    const firstPage = await this.getTickets(0, pageSize);
    const tickets = [...firstPage.content];

    for (let currentPage = 1; currentPage < firstPage.totalPages; currentPage += 1) {
      const nextPage = await this.getTickets(currentPage, pageSize);
      tickets.push(...nextPage.content);
    }

    return tickets;
  }

  async getTicket(id: number): Promise<Ticket> {
    const response = await this.client.get<Ticket>(`/tickets/${id}`);
    return response.data;
  }

  async createTicket(data: CreateTicketRequest): Promise<Ticket> {
    const response = await this.client.post<Ticket>('/tickets', data);
    return response.data;
  }

  async updateTicket(id: number, data: any): Promise<Ticket> {
    const response = await this.client.put<Ticket>(`/tickets/${id}`, data);
    return response.data;
  }

  async updateTicketStatus(id: number, status: string): Promise<Ticket> {
    const response = await this.client.patch<Ticket>(`/tickets/${id}/status?status=${status}`);
    return response.data;
  }

  async reassignTicket(id: number, newAssigneeUsername: string): Promise<Ticket> {
    const response = await this.client.post<Ticket>(
      `/tickets/${id}/reassign?newAssigneeUsername=${encodeURIComponent(newAssigneeUsername)}`
    );
    return response.data;
  }

  // Comments
  async addComment(ticketId: number, content: string, isInternal = false): Promise<any> {
    const response = await this.client.post(`/tickets/${ticketId}/comments`, {
      content,
      isInternal,
    });
    return response.data;
  }

  async getComments(ticketId: number, page = 0, size = 10): Promise<any> {
    const response = await this.client.get(`/tickets/${ticketId}/comments?page=${page}&size=${size}`);
    return response.data;
  }

  // Notifications
  async getNotifications(page = 0, size = 20): Promise<any> {
    const response = await this.client.get(`/notifications?page=${page}&size=${size}`);
    return response.data;
  }

  async getUnreadCount(): Promise<{ unreadCount: number }> {
    const response = await this.client.get<{ unreadCount: number }>('/notifications/unread/count');
    return response.data;
  }

  async markAsRead(notificationId: number): Promise<any> {
    const response = await this.client.patch(`/notifications/${notificationId}/read`);
    return response.data;
  }

  // Users
  async getProfile(): Promise<any> {
    const response = await this.client.get('/users/profile');
    return response.data;
  }

  async getAgents(): Promise<any> {
    const response = await this.client.get('/users/role/agents');
    return response.data;
  }

  async getAllAgents(): Promise<any[]> {
    const response = await this.client.get('/users/role/agents/all');
    return response.data;
  }


  async getUsers(page = 0, size = 50): Promise<any> {
    const response = await this.client.get(`/users?page=${page}&size=${size}`);
    return response.data;
  }

  async createUser(data: RegisterRequest): Promise<any> {
    const response = await this.client.post('/users', data);
    return response.data;
  }

  async updateUser(id: number, data: { firstName: string; lastName: string; status: string; role?: string; department?: string }): Promise<any> {
    const response = await this.client.put(`/users/${id}`, data);
    return response.data;
  }

  async getManagerStatistics(): Promise<ManagerStatistics> {
    const response = await this.client.get<ManagerStatistics>('/manager/statistics');
    return response.data;
  }

  async downloadManagerReport(): Promise<Blob> {
    const response = await this.client.get('/manager/statistics/report', { responseType: 'blob' });
    return response.data;
  }
}

export const apiClient = new ApiClient();
